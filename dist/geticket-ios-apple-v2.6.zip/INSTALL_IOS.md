# 🍎 GeTicket Pro - iPhone & iPad (iOS Orion Browser) Setup

## 🚀 আইফোনে ইনস্টলেশন গাইড:
১. Apple App Store থেকে **Orion Browser by Kagi** ইনস্টল করুন (এটি আইফোনে ডেক্সটপ ক্রোম এক্সটেনশন সাপোর্ট করে)।
২. Orion ওপেন করে Settings ➔ Extensions ➔ Enable Chrome Extensions অন করুন।
৩. Add Extension ➔ এই **geticket-ios-apple-v1.0.0.zip** ফাইলটি যুক্ত করুন।
৪. `eticket.railway.gov.bd` ওপেন করলেই GeTicket HUD চালু হয়ে যাবে।
