# 🤖 GeTicket Pro - Android Kiwi Browser Setup

## 🚀 কিউই ব্রাউজারে ইনস্টল করার নিয়ম:
১. Google Play Store থেকে **Kiwi Browser** ইনস্টল করুন।
২. কিউই ব্রাউজারের থ্রি-ডট (⋮) মেনু ➔ **Extensions**-এ যান।
৩. উপরে ডান কোণে থাকা **Developer mode** অন (ON) করুন।
৪. **+(from .zip / .crx / folder)** বাটনে ট্যাপ করে এই **geticket-android-kiwi-v1.0.0.zip** ফাইলটি সিলেক্ট করুন।

📌 **নোট:** ফাইলটি সিলেক্ট করলেই সাথে সাথে এক্সটেনশন লিস্টে GeTicket Pro যুক্ত হয়ে যাবে! এরপর eticket.railway.gov.bd-এ লগইন করুন।
