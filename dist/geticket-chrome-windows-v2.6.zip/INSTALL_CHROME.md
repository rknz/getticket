# 🪟 GeTicket Pro - Google Chrome (PC Windows / Mac / Linux) Setup

## 🚀 ৩-ধাপের সহজ ইনস্টলেশন:
১. এই ZIP ফাইলটি আপনার কম্পিউটারে যেকোনো ফোল্ডারে Extract (আনজিপ) করুন।
২. আপনার ক্রোম ব্রাউজারে যান: chrome://extensions/
৩. উপরে ডানপাশের **Developer mode** অন (ON) করুন। এরপর বামে থাকা **Load unpacked** বাটনে ক্লিক করে আনজিপ করা ফোল্ডারটি নির্বাচন করুন।

✅ GeTicket Pro চালু হয়ে গেছে! বাংলাদেশ রেলওয়ে পোর্টালে (eticket.railway.gov.bd) প্রবেশ করে টিকিট বুক করুন।
